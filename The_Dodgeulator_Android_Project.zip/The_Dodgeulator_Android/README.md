# The Dodgeulator — Android project

Open this folder in Android Studio and build the APK.

1. Open the project folder.
2. Let Gradle sync.
3. Build > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/.

The game is bundled locally in app/src/main/assets/index.html and runs fullscreen in an Android WebView.
